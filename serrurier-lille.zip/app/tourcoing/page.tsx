import CityPageTemplate from "../../components/city-page-template"

export default function TourcoingPage() {
  return <CityPageTemplate city="Tourcoing" />
}

