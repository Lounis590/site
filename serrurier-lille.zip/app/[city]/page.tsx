import { notFound } from "next/navigation"
import CityPageTemplate from "../../components/city-page-template"

const validCities = ["lille", "roubaix", "tourcoing", "villeneuve-d-ascq", "wattrelos", "marcq-en-baroeul"]

export function generateStaticParams() {
  return validCities.map((city) => ({ city }))
}

export default function CityPage({ params }: { params: { city: string } }) {
  const city = params.city.replace(/-/g, " ")
  const formattedCity = city.charAt(0).toUpperCase() + city.slice(1)

  if (!validCities.includes(params.city)) {
    notFound()
  }

  return <CityPageTemplate city={formattedCity} />
}

