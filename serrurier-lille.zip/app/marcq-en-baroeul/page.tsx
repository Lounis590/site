import CityPageTemplate from "../../components/city-page-template"

export default function MarcqEnBaroeulPage() {
  return <CityPageTemplate city="Marcq-En-Baroeul" />
}

