import ServicesSection from "../components/services-section"
import ReviewsSection from "../components/reviews-section"
import FAQSection from "../components/faq-section"
import SEOScript from "../components/seo-script"

export default function Home() {
  return (
    <>
      <SEOScript />
      <main className="min-h-screen bg-white">
        <ServicesSection />
        <ReviewsSection />
        <FAQSection />
      </main>
    </>
  )
}

