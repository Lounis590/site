import CityPageTemplate from "../../components/city-page-template"

export default function VilleneuveDascqPage() {
  return <CityPageTemplate city="Villeneuve d'Ascq" />
}

