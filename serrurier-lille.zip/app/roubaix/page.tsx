import CityPageTemplate from "../../components/city-page-template"

export default function RoubaixPage() {
  return <CityPageTemplate city="Roubaix" />
}

