import CityPageTemplate from "../../components/city-page-template"

export default function WattrelosPage() {
  return <CityPageTemplate city="Wattrelos" />
}

