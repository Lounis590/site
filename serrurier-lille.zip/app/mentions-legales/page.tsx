import Header from "../../components/header"
import Footer from "../../components/footer"

export default function MentionsLegales() {
  return (
    <>
      <Header city="Lille" />
      <main className="pt-24 md:pt-32 pb-16 px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Mentions légales</h1>
          <div className="space-y-4">
            <p>
              Conformément aux dispositions de la loi n° 2004-575 du 21 juin 2004 pour la confiance en l'économie
              numérique, il est précisé aux utilisateurs du site Serrurierassistance l'identité des différents
              intervenants dans le cadre de sa réalisation et de son suivi.
            </p>
            <h2 className="text-xl font-semibold mt-4">Edition du site</h2>
            <p>Le présent site, accessible à l'URL serrurierassistance.com (le « Site »), est édité par :</p>
            <p>
              Lounis Achour, 59200 Tourcoing, de nationalité Française (France), ainsi qu'au R.M. sous le numéro 931 455
              489 RM 59,
            </p>
            <h2 className="text-xl font-semibold mt-4">Hébergement</h2>
            <p>
              Le Site est hébergé par la société Wix Online Platform Limited, situé 1 Grant's Row, Dublin 2 D02HX96,
              Ireland, (contact téléphonique ou email : (+1) 415 358 0857).
            </p>
            <h2 className="text-xl font-semibold mt-4">Directeur de publication</h2>
            <p>Le Directeur de la publication du Site est Lounis Achour.</p>
            <h2 className="text-xl font-semibold mt-4">Nous contacter</h2>
            <p>
              Par téléphone : +33 3 74 47 48 10
              <br />
              Par email : serrurierassistance.pro@gmail.com
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

