import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import Header from "../components/header"
import type React from "react" // Added import for React

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Serrurier Lille Urgence 24/7🚨- Intervention Express en 10 Minutes",
  description:
    "Serrurier agréé à Lille, disponible 24h/24 pour dépannage urgent. Porte claquée, clé perdue, changement de serrure. Intervention en 10 minutes !",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        <Header />
        {children}
      </body>
    </html>
  )
}

