import Header from "./header"
import ServicesSection from "./services-section"
import ReviewsSection from "./reviews-section"
import FAQSection from "./faq-section"
import InterventionZones from "./intervention-zones"
import Footer from "./footer"
import SEOScript from "./seo-script"
import LilleSpecificContent from "./lille-specific-content"

interface CityPageProps {
  city?: string
}

export default function CityPageTemplate({ city = "Lille" }: CityPageProps) {
  const validCities = ["Lille", "Roubaix", "Tourcoing", "Villeneuve-d'Ascq", "Wattrelos", "Marcq-en-Barœul"]
  const displayCity = city && validCities.includes(city) ? city : "Lille"

  return (
    <>
      <SEOScript city={displayCity} />
      <Header city={displayCity} />
      <main className="min-h-screen bg-white">
        <ServicesSection city={displayCity} />
        <ReviewsSection city={displayCity} />
        <FAQSection city={displayCity} />
        {displayCity === "Lille" && <LilleSpecificContent />}
        <InterventionZones currentCity={displayCity} />
      </main>
      <Footer />
    </>
  )
}

