import { Star, CheckCircle2 } from "lucide-react"

interface ReviewCardProps {
  name: string
  avatarColor: string
  text: string
  hours: number
}

export default function ReviewCard({ name, avatarColor, text, hours }: ReviewCardProps) {
  return (
    <div className="bg-white rounded-lg w-[280px] h-[180px] mx-4 p-4 shadow-md flex flex-col">
      <div className="flex items-center gap-3 mb-2">
        <div
          className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${avatarColor}`}
        >
          {name[0]}
        </div>
        <div className="flex-grow">
          <div className="font-['Google_Sans'] font-medium text-[#202124] text-sm">{name}</div>
          <div className="flex items-center gap-1 text-[#fbbc04]">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={12} fill="#fbbc04" stroke="none" />
            ))}
            <CheckCircle2 size={12} className="text-[#34a853]" />
          </div>
        </div>
      </div>
      <div className="text-[#5f6368] text-sm leading-tight flex-grow">{text}</div>
      <div className="text-[#70757a] text-xs text-right mt-2">
        Il y a {hours} heure{hours > 1 ? "s" : ""}
      </div>
    </div>
  )
}

