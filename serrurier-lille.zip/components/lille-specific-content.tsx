export default function LilleSpecificContent() {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-6">Serrurier Lille : Votre Expert en Sécurité</h2>
        <div className="space-y-4 text-gray-700">
          <p>
            Situé au cœur de Lille, notre service de serrurerie est dédié à assurer votre sécurité 24h/24 et 7j/7. Que
            vous soyez dans le Vieux-Lille, à Wazemmes, ou dans n'importe quel quartier de la métropole lilloise, notre
            équipe d'experts intervient rapidement pour tous vos besoins en serrurerie.
          </p>
          <p>
            Nous sommes fiers de servir Lille et ses environs, offrant des solutions sur mesure pour la sécurité de
            votre domicile ou de votre entreprise. Notre connaissance approfondie de la ville nous permet d'intervenir
            efficacement, que ce soit pour une ouverture de porte dans le centre-ville animé ou l'installation d'un
            système de sécurité dans les zones résidentielles.
          </p>
          <p>
            En tant que serrurier Lille de confiance, nous nous engageons à fournir un service de qualité, rapide et
            fiable. Notre expertise couvre tous les aspects de la serrurerie moderne, des serrures traditionnelles aux
            systèmes de sécurité électroniques avancés.
          </p>
          <h3 className="text-xl font-semibold mt-6 mb-2">Nos services à Lille incluent :</h3>
          <ul className="list-disc pl-5 space-y-2">
            <li>Ouverture de porte sans dégâts</li>
            <li>Remplacement et installation de serrures</li>
            <li>Mise en sécurité après cambriolage</li>
            <li>Installation de portes blindées</li>
            <li>Dépannage de serrures électroniques</li>
            <li>Reproduction de clés de haute sécurité</li>
          </ul>
          <p className="mt-4">
            Faites confiance à votre serrurier Lille pour tous vos besoins en sécurité. Contactez-nous au 03 74 47 48 10
            pour un service rapide et professionnel, 24/7.
          </p>
        </div>
      </div>
    </section>
  )
}

