"use client"
import { Disclosure } from "@headlessui/react"
import { ChevronUpIcon } from "@heroicons/react/20/solid"
import Link from "next/link"

const faqs = [
  {
    question: "💰 Quels sont vos tarifs pour une ouverture de porte ?",
    answer: (
      <>
        <p>
          Nos tarifs <strong>serrurier Lille</strong> (TTC) (hors nuit/week-end):
        </p>
        <ul className="list-disc pl-5 space-y-1">
          <li>
            Porte claquée ou bloquée : <strong>94.90€</strong>
          </li>
          <li>
            Porte simple : <strong>124.90€</strong>
          </li>
          <li>
            Porte blindée : <strong>149.90€</strong>
          </li>
        </ul>
        <p>✔️ Devis gratuit par téléphone</p>
      </>
    ),
  },
  {
    question: "🚪 Comment sécuriser sa porte après une effraction ?",
    answer: (
      <>
        <p>Solutions de sécurité à Lille :</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>🔒 Installation serrure A2P*</li>
          <li>🛡️ Installation d'une poignée blindée</li>
          <li>📝 Attestation pour assurance</li>
          <li>🎥 Diagnostic sécurité gratuit</li>
        </ul>
      </>
    ),
  },
  {
    question: "📍 Intervenez-vous dans toute la métropole lilloise ?",
    answer: (
      <>
        <p>Oui, nous couvrons :</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Lille-Centre, Vieux-Lille, Wazemmes</li>
          <li>La Madeleine, Marcq-en-Barœul</li>
          <li>+30 communes autour de Lille</li>
        </ul>
      </>
    ),
  },
  {
    question: "🔩 Quelles marques de serrures utilisez-vous ?",
    answer: (
      <>
        <p>Marques professionnelles installées :</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Vachette - Fichet - Bricard</li>
          <li>Hercacles - Picard - ISEO</li>
          <li>Serrures brevetées et anti-crochetage</li>
        </ul>
      </>
    ),
  },
]

export default function FAQSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-extrabold text-gray-900 text-center mb-8">Foire Aux Questions</h2>
        <dl className="space-y-6">
          {faqs.map((faq, index) => (
            <Disclosure key={index} as="div" className="pt-6">
              {({ open }) => (
                <>
                  <dt className="text-lg">
                    <Disclosure.Button className="text-left w-full flex justify-between items-start text-gray-400">
                      <span className="font-medium text-gray-900">{faq.question}</span>
                      <span className="ml-6 h-7 flex items-center">
                        <ChevronUpIcon
                          className={`${open ? "-rotate-180" : "rotate-0"} h-6 w-6 transform`}
                          aria-hidden="true"
                        />
                      </span>
                    </Disclosure.Button>
                  </dt>
                  <Disclosure.Panel as="dd" className="mt-2 pr-12">
                    <div className="text-base text-gray-500">{faq.answer}</div>
                  </Disclosure.Panel>
                </>
              )}
            </Disclosure>
          ))}
        </dl>
        <div className="mt-12 bg-gray-900 rounded-lg shadow-xl overflow-hidden">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-white">Urgence Serrurerie à Lille ?</h3>
            <div className="mt-2 max-w-xl text-sm text-gray-300">
              <p>Intervention rapide 24h/24 et 7j/7</p>
            </div>
            <div className="mt-5">
              <Link
                href="tel:+33374474810"
                className="inline-flex items-center justify-center px-4 py-2 border border-transparent font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:text-sm"
              >
                📞 03 74 47 48 10
              </Link>
            </div>
            <p className="mt-3 text-sm text-gray-300">Devis gratuit par téléphone</p>
          </div>
        </div>
        <div className="mt-6 text-center">
          <Link
            href="/mentions-legales"
            className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition duration-300 inline-block"
          >
            Mentions légales
          </Link>
        </div>
      </div>
    </section>
  )
}

