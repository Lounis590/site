import Link from "next/link"

const zones = ["Lille", "Roubaix", "Tourcoing", "Villeneuve-d'Ascq", "Wattrelos", "Marcq-en-Barœul"]

interface InterventionZonesProps {
  currentCity: string
}

export default function InterventionZones({ currentCity }: InterventionZonesProps) {
  return (
    <section className="bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-center mb-6">Zones d'intervention</h2>
        <div className="flex flex-wrap justify-center gap-4">
          {zones.map((zone) => (
            <Link
              key={zone}
              href={`/${zone.toLowerCase().replace(/['\s]/g, "-")}`}
              className={`px-4 py-2 rounded-full ${
                zone === currentCity ? "bg-blue-600 text-white" : "bg-white text-blue-600 hover:bg-blue-100"
              }`}
            >
              {zone}
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

