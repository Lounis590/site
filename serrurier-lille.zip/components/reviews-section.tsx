"use client"

import { useEffect, useRef } from "react"
import ReviewCard from "./review-card"

const reviews = [
  {
    name: "Léa D.",
    avatarColor: "bg-[#4285f4]",
    text: "Intervention rapide à Lille. Porte ouverte en 15 min. Serrurier pro !",
    hours: 3,
  },
  {
    name: "Hugo L.",
    avatarColor: "bg-[#34a853]",
    text: "Changement de serrure impeccable. Sécurité renforcée, prix correct.",
    hours: 8,
  },
  {
    name: "Emma R.",
    avatarColor: "bg-[#ea4335]",
    text: "Dépannage 24/7 au top. Réactif et efficace sur Lille.",
    hours: 12,
  },
  {
    name: "Thomas M.",
    avatarColor: "bg-[#fbbc05]",
    text: "Conseils pertinents pour sécuriser mon appart dans le Vieux-Lille.",
    hours: 24,
  },
  {
    name: "Zoé Ambre",
    avatarColor: "bg-[#db4437]",
    text: "Ouverture de porte sans dégât. Rapide et pro. Merci !",
    hours: 6,
  },
  {
    name: "Eliott Sky",
    avatarColor: "bg-[#0f9d58]",
    text: "Installation serrure haute sécurité parfaite. Recommande !",
    hours: 18,
  },
  {
    name: "Jade Océane",
    avatarColor: "bg-[#4285f4]",
    text: "Urgence serrure résolue en 20 min. Service au top sur Lille !",
    hours: 2,
  },
  {
    name: "Nolan Feu",
    avatarColor: "bg-[#f4b400]",
    text: "Remplacement cylindre express. Travail soigné, prix correct.",
    hours: 36,
  },
  {
    name: "Inès Lune",
    avatarColor: "bg-[#db4437]",
    text: "Dépannage nocturne efficace. Serrurier fiable à Lille.",
    hours: 4,
  },
  {
    name: "Léo Soleil",
    avatarColor: "bg-[#4285f4]",
    text: "Réparation serrure cassée rapide. Service client excellent !",
    hours: 10,
  },
  {
    name: "Chloé Rose",
    avatarColor: "bg-[#0f9d58]",
    text: "Intervention express centre-ville. Serrurier Lille au top !",
    hours: 15,
  },
  {
    name: "Axel Ciel",
    avatarColor: "bg-[#f4b400]",
    text: "Changement serrure porte blindée impeccable. Sécurité ++",
    hours: 28,
  },
  {
    name: "Manon Étoile",
    avatarColor: "bg-[#db4437]",
    text: "Ouverture coffre-fort réussie. Pro et discret. Merci !",
    hours: 7,
  },
  {
    name: "Enzo Vent",
    avatarColor: "bg-[#4285f4]",
    text: "Dépannage serrure voiture rapide. Sauvé ma journée !",
    hours: 20,
  },
]

export default function ReviewsSection() {
  const wrapperRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const wrapper = wrapperRef.current
    if (wrapper) {
      wrapper.innerHTML += wrapper.innerHTML
    }
  }, [])

  return (
    <section className="w-full py-5 overflow-hidden bg-white">
      <div className="flex" ref={wrapperRef} style={{ animation: "scroll 16s linear infinite" }}>
        {reviews.map((review, index) => (
          <ReviewCard key={index} {...review} />
        ))}
      </div>
    </section>
  )
}

