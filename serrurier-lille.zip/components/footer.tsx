export default function Footer() {
  return (
    <footer className="bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <div className="text-center text-sm text-gray-600">
          <p>
            &copy; 2024 Serrurier Assistance. Tous droits réservés.{" "}
            <a href="https://www.serrurierassistance.fr" className="text-blue-600 hover:underline">
              www.serrurierassistance.fr
            </a>
          </p>
          <p className="mt-2"> 931 455 489</p>
          <p className="mt-2">Siège social : 14 rue du vieux faubourg 59800 Lille </p>
        </div>
      </div>
    </footer>
  )
}

