import Image from "next/image"
import Link from "next/link"

interface HeaderProps {
  city?: string
}

export default function Header({ city = "Lille" }: HeaderProps) {
  const displayCity = city || "Lille"
  return (
    <header className="bg-black text-white w-full font-sans fixed top-0 left-0 right-0 z-50">
      <div className="max-w-[980px] mx-auto px-4">
        <div className="flex justify-between items-center h-16 md:h-20">
          <Link href="/" className="flex-shrink-0">
            <div className="relative w-20 h-20 md:w-24 md:h-24">
              <Image
                src="https://i.ibb.co/GfBhngM8/logo.webp"
                alt={`Serrurier ${displayCity} Urgence - Logo - Intervention rapide 24/7`}
                layout="fill"
                objectFit="contain"
                priority
              />
            </div>
          </Link>

          <h1 className="text-sm font-bold md:text-xl text-center flex-grow">
            Serrurier {displayCity} Urgence 24/7 🚨
          </h1>

          <a
            href="tel:0374474810"
            className="bg-[#D90429] hover:bg-[#B00321] text-white py-2 px-4 rounded-full font-bold flex items-center gap-2 transition duration-300 text-sm md:text-base whitespace-nowrap"
          >
            <svg className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
            </svg>
            03 74 47 48 10
          </a>
        </div>
      </div>
    </header>
  )
}

