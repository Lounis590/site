import Link from "next/link"
import ServiceCard from "./service-card"
import { PhoneIcon } from "lucide-react"

interface ServicesSectionProps {
  city: string
}

export default function ServicesSection({ city = "Lille" }: ServicesSectionProps) {
  const displayCity = city || "Lille"
  const isLille = displayCity === "Lille"
  return (
    <section className="py-8 md:py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-center text-3xl md:text-4xl font-bold text-[#2B2D42] mb-2 mt-20 md:mt-24">
          {isLille ? "Serrurier Lille : Interventions Express 24/7" : `Nos Interventions Express à ${displayCity}`}
        </h2>
        {isLille && (
          <p className="text-center text-lg text-gray-600 mt-2 mb-4">
            Votre serrurier de confiance à Lille et dans toute la métropole lilloise
          </p>
        )}
        <div className="w-16 h-1 bg-[#D90429] mx-auto mb-8 md:mb-12"></div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <ServiceCard
            badge={`Le moins cher de ${displayCity} 💶`}
            title="Porte Claquée"
            description={`Dépannage Porte Claquée à ${displayCity} - Intervention Express 10min`}
            price="94,90€"
            features={[
              "Intervention en 10 minutes⏱️",
              "Sans casse garantie 🔒",
              `Déplacement 0€ à ${displayCity} et alentours 🚗`,
            ]}
          />
          <ServiceCard
            badge="Remboursé par votre assurance✅"
            title="Porte fermée / Clé perdue"
            description={`Ouverture Porte Fermée à ${displayCity} - Clé Perdue ou Cassée`}
            price="124.90€"
            features={[
              "Ouverture rapide🚨",
              "Remplacement de clé ou serrure sur place 🔧",
              `Serrurier de ${displayCity} certifié et recommandé par les assurances 🔒`,
            ]}
          />
          <ServiceCard
            badge="Diagnostic immédiat🔍"
            title="Serrure cassée ou dysfonctionnante"
            description={`Réparation Serrure Cassée à ${displayCity} - Remplacement Express`}
            price="124.90€"
            features={[
              "Réparation ou remplacement de serrure en 30 minutes ⏱️",
              `Disponible 24h/24 et 7j/7 à ${displayCity} et alentours🚨`,
              "Tarif transparent 💶",
            ]}
          />
          <ServiceCard
            badge="Sécurité renforcée 🛡️"
            title="Changement de Serrure"
            description={`Installation de Nouvelle Serrure à ${displayCity} - Service Professionnel`}
            price="89,90€"
            features={[
              "Installation rapide et efficace ⚡",
              "Large choix de serrures de qualité 🔐",
              "Conseils personnalisés pour votre sécurité 👨‍🔧",
            ]}
          />
        </div>

        <div className="text-center mt-8 md:mt-12">
          <Link
            href="tel:+33374474810"
            className="inline-flex items-center gap-2 bg-[#D90429] text-white px-6 py-3 md:px-8 md:py-4 rounded-full font-medium transition-colors hover:bg-[#B00321] text-lg md:text-xl"
          >
            <PhoneIcon className="w-6 h-6" />
            03 74 47 48 10
          </Link>
          <p className="text-gray-600 mt-4 text-sm md:text-base">
            ✔ Toutes interventions garanties - Facture assurance fournie
          </p>
        </div>
      </div>
    </section>
  )
}

