"use client"

import { useState } from "react"
import { X } from "lucide-react"

export default function LegalPopup() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="text-blue-600 hover:underline font-semibold bg-white px-4 py-2 rounded-full shadow-md transition-all duration-300 hover:shadow-lg"
      >
        Mentions légales
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="text-xl font-bold">Mentions légales</h2>
              <button onClick={() => setIsOpen(false)}>
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-4 space-y-4 text-sm">
              <p>
                Conformément aux dispositions de la loi n° 2004-575 du 21 juin 2004 pour la confiance en l'économie
                numérique, il est précisé aux utilisateurs du site Serrurierassistance l'identité des différents
                intervenants dans le cadre de sa réalisation et de son suivi.
              </p>
              <h3 className="font-bold">Edition du site</h3>
              <p>Le présent site, accessible à l'URL serrurierassistance.com (le « Site »), est édité par :</p>
              <p>
                Lounis Achour, 59200 Tourcoing, de nationalité Française (France), ainsi qu'au R.M. sous le numéro 931
                455 489 RM 59,
              </p>
              <h3 className="font-bold">Hébergement</h3>
              <p>
                Le Site est hébergé par la société Wix Online Platform Limited, situé 1 Grant's Row, Dublin 2 D02HX96,
                Ireland, (contact téléphonique ou email : (+1) 415 358 0857).
              </p>
              <h3 className="font-bold">Directeur de publication</h3>
              <p>Le Directeur de la publication du Site est Lounis Achour.</p>
              <h3 className="font-bold">Nous contacter</h3>
              <p>
                Par téléphone : +33 3 74 47 48 10
                <br />
                Par email : serrurierassistance.pro@gmail.com
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

