import Head from "next/head"

interface SEOScriptProps {
  city?: string
}

export default function SEOScript({ city = "Lille" }: SEOScriptProps) {
  const displayCity = city || "Lille"
  const formattedCity = displayCity.toLowerCase().replace(/['\s]/g, "-")

  return (
    <Head>
      <title>{`Serrurier ${displayCity} 🔑 | Urgence 24/7 & Intervention Express en 10 Minutes`}</title>
      <meta
        name="description"
        content={`Serrurier agréé à ${displayCity}, disponible 24h/24 pour dépannage urgent. Porte claquée, clé perdue, changement de serrure. Intervention en 10 minutes ! Devis gratuit au 03 74 47 48 10.`}
      />
      <meta
        name="keywords"
        content={`serrurier ${displayCity}, serrurier ${displayCity} urgence, dépannage serrurier ${displayCity}, urgence serrurerie ${displayCity}, serrurerie ${displayCity}, serrurier pas cher ${displayCity}, ouverture de porte ${displayCity}, changement de serrure ${displayCity}, réparation serrure ${displayCity}`}
      />
      <meta property="og:title" content={`Serrurier ${displayCity} 🔑 | Urgence 24/7 & Intervention Rapide`} />
      <meta
        property="og:description"
        content={`Serrurier ${displayCity} Urgence 24/24 - Intervention express en 10min. Dépannage, ouverture de porte, changement de serrure. Devis gratuit et sans engagement.`}
      />
      <meta property="og:type" content="website" />
      <meta property="og:url" content={`https://www.serrurierassistance.fr/${formattedCity}`} />
      <meta property="og:image" content="https://www.serrurierassistance.fr/og-image.jpg" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={`Serrurier ${displayCity} | Urgence 24/7 & Intervention Rapide`} />
      <meta
        name="twitter:description"
        content={`Serrurier agréé à ${displayCity}. Intervention en 10 minutes pour ouverture de porte, changement de serrure. Disponible 24/7. Appelez le 03 74 47 48 10.`}
      />
      <meta name="twitter:image" content="https://www.serrurierassistance.fr/twitter-image.jpg" />
      <link rel="canonical" href={`https://www.serrurierassistance.fr/${formattedCity}`} />
      <meta name="geo.region" content="FR-59" />
      <meta name="geo.placename" content={displayCity} />
      <meta name="geo.position" content="50.6292;3.0573" />
      <meta name="ICBM" content="50.6292, 3.0573" />
    </Head>
  )
}

