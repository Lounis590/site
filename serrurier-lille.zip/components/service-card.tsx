import { CheckIcon } from "lucide-react"

interface ServiceCardProps {
  badge: string
  title: string
  description: string
  price: string
  features: string[]
}

export default function ServiceCard({ badge, title, description, price, features }: ServiceCardProps) {
  return (
    <article className="border border-gray-200 rounded-xl p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-red-100 hover:border-red-200 bg-white relative overflow-hidden">
      <div className="absolute top-0 right-0 bg-[#D90429] text-white py-1 px-3 rounded-bl-xl text-sm">{badge}</div>
      <h3 className="text-[#2B2D42] text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <div className="text-[#D90429] text-4xl font-bold mb-4">{price}</div>
      <ul className="space-y-2">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center gap-2">
            <CheckIcon className="w-5 h-5 text-[#D90429] flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </article>
  )
}

